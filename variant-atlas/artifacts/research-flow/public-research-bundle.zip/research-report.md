# What do published studies show about PTEN mutations, protein function and the limits of structural evidence?

Bramha Atlas · Research report · completed with limitations

An automatically compiled, unreviewed public-evidence research report. It is not a published paper or an independent laboratory experiment.

## Abstract
Acquired 3 public studies and 3 structural references. 9 reported observations passed source-identity checks.

## Research question and methods
What do published studies show about PTEN mutations, protein function and the limits of structural evidence?

Execution: agentic. Public literature acquisition, source passage review, coordinate tracing and recorded verification; inspect worker outcomes below.

Findings describe what the acquired studies report. Source-identity checks do not establish causation, clinical benefit or a newly computed genetic or molecular structure.

## Results and their meaning
### Observation 1
PTEN alterations identified in cervical NEC tumors co-occur with oncogenic drivers including HER2, KRAS or PIK3CA.
Evidence type: reported study observation · reviewer status: unreviewed

> changes was assessed with PolyPhen-2, with scores > 0.85 considered probably damaging. Results PTEN alterations were identified in 25.0% (3/12) of tumors, encompassing four truncating mutations (p.W111*, p.Q171*, p.Q245*, p.R335*) and three missense variants (p.R130Q, p.E394G, p.D395V). A TP53 DNA-binding domain hotspot mutation, p.R273H, was detected in 8.33% (1/12). These tumor-suppressor lesions frequently co-occurred with oncogenic driver mutations, including HER2/PTEN (8.33%), PIK3CA/PTEN (8.33%), and a KRAS/PTEN/TP53 "triple-hit" (8.33%), underscoring multipathway genomic complexity. Conclusions Our findings suggest a genomic
Source: study-023ce70c23da9a5c746c1570 · passage passage-bac320c04b1b795397bfac20 · version 290841fdecdeeced053ebbe26c81ac34d78775874384d8f87a955133836adc5a

### Observation 2
Structural mapping indicates associations of TP53 and PTEN variants with pathway activation in cervical NEC samples.
Evidence type: reported study observation · reviewer status: unreviewed

> landscape consistent with a multihit hypothesis in cervical NEC, in which disruption of the reciprocal tumor-suppressive PTEN-p53 axis (25.0% and 8.33%, respectively) co-occurs with oncogenic HER2, KRAS, or PIK3CA alterations. Structural mapping indicates that TP53 p.R273H gain-of-function mutations and PTEN loss-of-function variants are associated with sustained PI3K/AKT/mTOR pathway activation. Integrating TP53 and PTEN status with oncogenic driver profiling may facilitate the identification of biologically defined subsets and inform precision therapeutic strategies for cervical NEC.
Source: study-023ce70c23da9a5c746c1570 · passage passage-71f010d918aea2807695d7e7 · version 290841fdecdeeced053ebbe26c81ac34d78775874384d8f87a955133836adc5a

### Observation 3
WES or WGS alongside immunohistochemical examination of PTEN protein expression may be used in suspected cases.
Evidence type: reported study observation · reviewer status: unreviewed

> gene is found in the patient, the diagnosis of PHTS can be genetically confirmed ( 10 ). Whole-exome sequencing (WES) or whole-genome sequencing (WGS) may be used to find rare variants or structural abnormalities that conventional methods might overlook in people with strong clinical suspicion but negative results from traditional genetic testing ( 19 ). Furthermore, immunohistochemical examination of PTEN protein expression in tumor tissues can be a useful supplementary technique to help confirm the diagnosis in suspected cases ( 20 ).
> In terms of therapy, endoscopic or surgical resection is recommended for pertinent tumors or severe
Source: study-40ff72fc6c5a8cae8a315926 · passage passage-8f29f4bb70ab08aee39e779a · version 61862a3414a8f0dd5f69f1bd4d6d65c9de29b7f4e4d8fc6384d0737eaed43b45

### Observation 4
Trio-based WES identified coexisting de novo variants in PTEN and SDHB in a single pediatric PHTS case.
Evidence type: reported study observation · reviewer status: unreviewed

> abdominal pain at the age of 8, with symptoms persisting for over six months. The patient's medical history includes diagnoses of macrocephaly, colonic polyps, gastritis, and hypogammaglobulinemia. Upon physical examination, the patient's skin was intact, showing no signs of rash, jaundice, petechiae, or ecchymosis. Additionally, the oral mucosa was moist, and skin elasticity was within normal limits. Trio-based WES was conducted, identifying coexisting de novo variants in PTEN and SDHB . This case may further expand the reported clinical and molecular spectrum of PHTS.
Source: study-40ff72fc6c5a8cae8a315926 · passage passage-b6bfd292c97453b3a070a6e9 · version 61862a3414a8f0dd5f69f1bd4d6d65c9de29b7f4e4d8fc6384d0737eaed43b45

### Observation 5
Protein structural coordinates for related variants obtained from RCSB PDB; single-case study limits generalizability.
Evidence type: reported study observation · reviewer status: unreviewed

> Protein structural coordinates for SDHB variants were obtained from the RCSB Protein Data Bank (PDB ID: 8GS8).
Source: study-40ff72fc6c5a8cae8a315926 · passage passage-a8623cd6796b431e7dad5ebd · version 61862a3414a8f0dd5f69f1bd4d6d65c9de29b7f4e4d8fc6384d0737eaed43b45

## Molecular and genetic context
### 8GS8: cryo-EM structure of the human respiratory complex II
Relationship: structure mentioned in source text. Method: ELECTRON MICROSCOPY.
https://www.rcsb.org/structure/8GS8
This is an acquired coordinate reference. Its presence does not establish a mutation effect, binding change or new genome.

### 2K20: Solution structure of Par-3 PDZ3 in complex with PTEN peptide
Relationship: related gene reference; not a structure generated by this study. Method: SOLUTION NMR.
https://www.rcsb.org/structure/2K20
This is an acquired coordinate reference. Its presence does not establish a mutation effect, binding change or new genome.

### 1CKW: CYSTIC FIBROSIS TRANSMEMBRANE CONDUCTANCE REGULATOR: SOLUTION STRUCTURES OF PEPTIDES BASED ON THE PHE508 REGION, THE MOST COMMON SITE OF DISEASE-CAUSING DELTA-F508 MUTATION
Relationship: related gene reference; not a structure generated by this study. Method: SOLUTION NMR.
https://www.rcsb.org/structure/1CKW
This is an acquired coordinate reference. Its presence does not establish a mutation effect, binding change or new genome.

## Discussion and research implications
Findings describe what the acquired studies report. Source-identity checks do not establish causation, clinical benefit or a newly computed genetic or molecular structure.
Further experiments should be designed against the specific study system, original methods and evidence gaps below. This compilation does not estimate an effect beyond the supplied measurements.

## Limitations and incomplete work
- Single case description limits generalizability of variant interactions
- Precise mechanism between PTEN and SDHB remains unresolved per discussion
- Single case study limits generalizability
- Precise mechanism of potential PTEN-SDHB interaction unresolved
- Current ClinVar classification of SDHB variant remains VUS despite proposed reinterpretation
- Structural evidence scope limited to cited observations; no broader protein function data synthesized
- Missing evidence on PTEN protein function across studies; disagreements absent but contexts differ (NEC vs PHTS)
- A source-linked reconstruction is not an independent experimental reproduction.
- Related reference structures do not establish a mutant fold, binding or causal mechanism.

## Agent methods and execution
- Research lead · completed · language model · openrouter / x-ai/grok-4.3: Saved ranked directions and bounded source queries.
- Evidence scout · completed · deterministic tools: Publication identities, original text coverage and affiliations retained.
- Structural scout · completed · deterministic tools: Publication-linked models are distinguished from related reference structures.
- Methods reviewer · completed · language model · openrouter / x-ai/grok-4.3: 3 source-linked observations retained for verification.
- Outcome reviewer · completed · language model · openrouter / x-ai/grok-4.3: 6 source-linked observations retained for verification.
- Research lead · route review · completed · language model · openrouter / x-ai/grok-4.3: Additional passages needed to review full details on PTEN variant structural mapping and functional implications in the cervical NEC study.
- Follow-up scout · completed · deterministic source tools: 3 saved original-language passages inspected; no additional interpretation was invented.
- Evidence verifier · completed · deterministic tools: Reference and quotation consistency checked; scientific truth remains unreviewed.
- Research lead · synthesis · completed · language model · openrouter / x-ai/grok-4.3: Checked reports reconciled; limitations retained.

## Research paths and possible follow-up
- Search studies on PTEN mutations · completed: Public sources are archived and versioned.
- Read passages on PTEN function · completed: 3 saved original-language passages inspected; no additional interpretation was invented.
- Extract sequence mentions in PTEN papers · completed: Exact mentions retained with their original passage identities.
- Trace PTEN structures · completed: Coordinate references acquired.
- Verify quotes on structural evidence · completed: Literal quotes and source versions checked.
- Synthesize PTEN evidence · completed: Checked worker reports retained; inspect the synthesis worker status and limitations.

## References
1. Zhang Y, Lee S, Annes JP, Zhang J, Zhou T, Deng X, Qian Y. (2026). Coexisting PTEN and SDHB Mutations in a Pediatric Patient with PTEN Hamartoma Tumor Syndrome: a case report.. https://europepmc.org/article/MED/42582518
   Actual coverage: open-access body text. Original source licence: https://creativecommons.org/licenses/by/4.0/ This is an open-access article distributed under the terms of the Creative Commons Attribution License (CC BY) . The use, distribution or reproduction in other forums is permitted, provided the original author(s) and the copyright owner(s) are credited and that the original publication in this journal is cited, in accordance with accepted academic practice. No use, distribution or reproduction is permitted which does not comply with these terms.. Version: 61862a3414a8f0dd5f69f1bd4d6d65c9de29b7f4e4d8fc6384d0737eaed43b45.
2. Shen HP, Lee MY, Lee YJ, Chen AC, Chen CK, Chao WR, Han CP. (2026). Integrated Genomic Profiling of PTEN and TP53 in Cervical Neuroendocrine Carcinoma: Synergistic Roles With HER2/KRAS/PIK3CA and Implications for Precision Oncology.. https://europepmc.org/article/MED/42765697
   Actual coverage: indexed abstract. Original source licence: Inspect original source for rights. Version: 290841fdecdeeced053ebbe26c81ac34d78775874384d8f87a955133836adc5a.
3. Sun L, Rodriguez L, Pankow S, Diedrich J, Qin K, Zhang J, Wu X, Wu P, Yates JR. (2026). Inhibition of the QPCT-PDIA4 axis rescues ΔF508 and N1303K CFTR in cystic fibrosis.. https://europepmc.org/article/MED/42265113
   Actual coverage: open-access body text. Original source licence: https://creativecommons.org/licenses/by-nc-nd/4.0/ Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence to share adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by-nc-nd/4.0/ .. Version: 818f0bb4a9fb2fca4d43f2e3954c9e903b139b89a78454bfbbe10d07e7213fb8.

## Reproducibility
Run: expedition-e81aeac31bb94dc4a1d1720c5add63ae
Started: 2026-10-25T07:39:59.771010+00:00 · stopped: 2026-10-25T07:41:48.469507+00:00 · report: 2026-10-25T09:17:18.896937+00:00
Model attempts: 10 / 12; tool operations: 4.
Reports omit project notes, uploaded private papers, prompts, credentials and raw model responses.
